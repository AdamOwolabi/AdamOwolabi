/**
 * PolyTest - CE Polymorphism
 * Copyright 2021 Howard Community College
 * @author Adam Owolabi
 * @version 1.0
 */

public class PolyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Combatant myArray[] = new Combatant[4];
		
		Gladiator myGladiator = new Gladiator();
		Ogre myOgre = new Ogre();
		Gladiator myGladiator2 = new Gladiator();
		Goblin myGoblin = new Goblin();
		
		myArray[0] = myGladiator;
		myArray[1] = myOgre;
		myArray[2] = myGladiator2;
		myArray[3] = myGoblin;
		
		System.out.println("Copyright 2021 Howard Community College\n");
		
		
		for(int i = 0; i< myArray.length; i++) {
			myArray[i].toString();
			System.out.println(myArray[i]);
		}
	
		System.out.println();
		for(int i = 0; i< myArray.length; i++) {
			//my.setCurrentHealth(20);
			myArray[i].setCurrentHealth(20);
			System.out.println(myArray[i]);
			
		}
	}
}
