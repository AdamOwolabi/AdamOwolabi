
abstract public class  Weapon {

	private double cost;
	private int damage;
	
	//toString method
	@Override
	public String toString() {
		return "Weapon [cost= %.2f" + cost + ", damage=%d" + damage + "]";
	}
	//zero parameter constructor
	public Weapon() {
		cost = 0;
		damage = 0;
	}
	// Full parameter constructor
	public Weapon(double cost, int damage) {
	this.cost = cost;
	this.damage = damage;
	}

	//Getters and setters
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public int getDamage() {
		return damage;
	}
	public void setDamage(int damage) {
		this.damage = damage;
	}
	
}
