public class Gladiator implements Combatant {

	// instance variables
	private String name;
	public int currentHealth;
	private Club weapon;
	private Rags armor;
	double treasureCarried;
	int damage = 0;
	
	public Club getWeapon() {
		return weapon;
	}

	public void setWeapon(Club weapon) {
		this.weapon = weapon;
	}

	public Rags getArmor() {
		return armor;
	}

	public void setArmor(Rags armor) {
		this.armor = armor;
	}
	
	public double getTreasureCarried() {
		return treasureCarried;
	}

	public void setTreasureCarried(double treasureCarried) {
		this.treasureCarried = treasureCarried;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCurrentHealth() {
		return currentHealth;
	}

	public void setCurrentHealth(int currentHealth) {
		this.currentHealth = currentHealth;
	
	}
	@Override
	public void attack(Combatant defender, int damageDealt) {
		System.out.println(name + ", the Gladiator,  is attacking");
		Goblin op = new Goblin();
		op.getAttacked(op, 0);
	
	}

	@Override
	public void getAttacked(Combatant attacker, int damageSustained) {
		System.out.println("The Gladiator is gettting ready to be attacked");
		
		
		damage = damageSustained;
		currentHealth -= damage;
		System.out.println();

		if (currentHealth >= 1) {
			System.out.println("Gladiator is still alive");
		} else {
			System.out.println("Gladiator has been killed");
		}
	}
			

	@Override
	public String toString() {
		return "Gladiator [name=" + name + ", currentHealth=" + currentHealth + ", weapon=" + weapon + ", armor="
				+ armor + ", treasureCarried=" + treasureCarried+"]";
	}

	
	// constructor
	public Gladiator() {
		
	 this("The Masked", 10, new Club(), new Rags(),10.0);
	
	}
	// constructor that receives 3 parameter
	public Gladiator(String name, int currentHealth, Club weapon, Rags armor, double treasureCarried) {
		
		this.name = name;
		this.currentHealth = currentHealth;
		this.weapon = weapon;
		this.armor = armor;
		this.treasureCarried = treasureCarried;
	}

	// methods to set the name in the object

	
}
