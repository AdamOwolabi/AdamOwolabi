
public class Kevlar extends Armor {
	private String quality;

	public Kevlar() {
		super();
		this.setCost(4.5);
		this.setDamage(3);
		quality = "Strong";
	}
	
	@Override
	public String toString() {
		return "Armor: Kevlar[cost=" + this.getCost() + ", damage=" + this.getDamage() + ", quality=" + quality + "]";
	}
	
	public Kevlar(double cost, int damage, String quality) {
		super(cost, damage);
		this.quality= quality;
	}


	public void setQuality(String quality) {
		this.quality = quality;
	}
	public String getQuality() {
		return quality;
	}
}
