import java.util.Scanner;

/**
 * Arena - An driver class for class exercise: CE_Abstraction Copyright 2021
 * Howard Community College
 * 
 * @author ADAM OWOLABI
 * @version 2.0
 *
 */
public class Arena {
// define the constants in the constant block
// main menu constants
	private static final int ARENA = 1;
	private static final int QUIT = 5;
	private static final int REST = 2;
	private static final int SHOP = 3;
	private static final int STATUS = 4;
// monster menu constants
	private static final int GOBLIN = 1;
	private static final int OGRE = 2;
	private static final int GIANT = 3;
	private static final int DRAGON = 4;
// monster damage constants
	private static final int GOBLIN_DAMAGE = 3;
	private static final int OGRE_DAMAGE = 5;
	private static final int GIANT_DAMAGE = 8;
	private static final int DRAGON_DAMAGE = 13;
//weapon menu constants 
	private static final int CLUB = 1;
	private static final int SWORD = 2;
	private static final int ARROW = 3;
	private static final int GUN = 4;
//armor menu constants
	private static final int RAGS = 1;
	private static final int LEATHER = 2;
	private static final int KEVLAR = 3;
	private static final int IRON = 4;
	
// other constants
	private static final double SILVER = 10.0;
	private static final double STD_WINDFALL = 2.0;
	private static final double REST_COST = 1.0;

	public static void main(String[] args) {
		System.out.println("Copyright 2021 Howard Community College\n");
		Scanner myScanner = new Scanner(System.in);
		String name = "";
		int hitPoints = 0;
		int action = 0; // this the sentinel LCV (loop control variable)
		int monsterChoice = 0;
		int weaponChoice = 0;
		int arenaChoice = 0;
		boolean isAlive = false; // opponent status
		String monsterName = "";
		String boutOutcome = "";
		int damage = 0;
		int smallHealth;
		double windfall = 0.0; // represents the winner take all in a battle
		System.out.println("Welcome to the Arena of Doom!");
		System.out.print("What is your name, gladiator? ");
		name = myScanner.next();
// instantiate a Gladiator with the 0-arg constructor
		Gladiator myGladiator = new Gladiator();
		myGladiator.setName(name);
		while (action != QUIT) {
			action = getValidMenuChoice(myScanner);
			switch (action) {
			case ARENA:
				monsterChoice = getValidMonsterChoice(myScanner);
				/*
				 * When the user fights a monster, and that monster is not a goblin, then modify
				 * the fighting code to: Update the Gladiator's state using the instance methods
				 * of the gladiator and the constants declared in AoD.
				 * 
				 * For example, the gladiator should lose OGRE_DAMAGE health when fighting an
				 * Ogre. The gladiator gains 2 silver. Hard-code this amount for now, but put a
				 * comment just above each hard-coded law that says // TODO: update this hard-
				 * coded value.
				 */
				switch (monsterChoice) {
				case GOBLIN:
					System.out.print("Enter the goblin's intial health points: ");
					hitPoints = myScanner.nextInt();
					damage = GOBLIN_DAMAGE;
					monsterName = "Goblin";
					Goblin myGoblin = new Goblin(hitPoints, damage, SILVER, 8);
					do {
						if(myGladiator.getCurrentHealth() < myGoblin.getCurrentHealth()) {
							
							smallHealth = myGladiator.getCurrentHealth();
						} else {
							smallHealth = myGoblin.getCurrentHealth();
						}
						myGoblin.setCurrentHealth(myGoblin.getCurrentHealth()-myGladiator.getWeapon().getDamage());
						myGladiator.setCurrentHealth(myGladiator.getCurrentHealth() - GOBLIN_DAMAGE);
					} while(smallHealth != 0);
					
					

					myGladiator.attack(myGoblin, myGladiator.getWeapon().getDamage());// was goblin killed?
					
					isAlive = (myGoblin.getCurrentHealth() > 0);
					if (isAlive) {
						windfall = 0;
						boutOutcome = "inflicted damage on";
// Goblin counter-attacks
						myGoblin.attack(myGladiator, damage);
					} else {
						windfall = myGoblin.getTreasureCarried();
						boutOutcome = "defeats";
					}
					break;
				case OGRE:
					monsterName = "Ogre";
					damage = OGRE_DAMAGE;
					windfall = STD_WINDFALL;
					
					Ogre myOgre = new Ogre(hitPoints, damage, SILVER, "myTribe");
					do {
						if(myGladiator.getCurrentHealth() < myOgre.getCurrentHealth()) {
							
							smallHealth = myGladiator.getCurrentHealth();
						} else {
							smallHealth = myOgre.getCurrentHealth();
						}
						myOgre.setCurrentHealth(myOgre.getCurrentHealth()-myGladiator.getWeapon().getDamage());
						myGladiator.setCurrentHealth(myGladiator.getCurrentHealth() - OGRE_DAMAGE);
					} while(smallHealth != 0);
					
					myGladiator.attack(myOgre, myGladiator.getWeapon().getDamage());// was Ogre killed?
					break;
				case GIANT:
					monsterName = "Giant";
					damage = GIANT_DAMAGE;
					windfall = STD_WINDFALL;
					Giant myGiant = new Giant();
					do {
						if(myGladiator.getCurrentHealth() < myGiant.getCurrentHealth()) {
							
							smallHealth = myGladiator.getCurrentHealth();
						} else {
							smallHealth = myGiant.getCurrentHealth();
						}
						myGiant.setCurrentHealth(myGiant.getCurrentHealth()-myGladiator.getWeapon().getDamage());
						myGladiator.setCurrentHealth(myGladiator.getCurrentHealth() - GIANT_DAMAGE);
					} while(smallHealth != 0);
					break;
				case DRAGON:
					monsterName = "Dragon";
					damage = DRAGON_DAMAGE;
					windfall = STD_WINDFALL;
					Dragon myDragon = new Dragon();
					do {
						if(myGladiator.getCurrentHealth() < myDragon.getCurrentHealth()) {
							
							smallHealth = myGladiator.getCurrentHealth();
						} else {
							smallHealth = myDragon.getCurrentHealth();
						}
						myDragon.setCurrentHealth(myDragon.getCurrentHealth()-myGladiator.getWeapon().getDamage());
						myGladiator.setCurrentHealth(myGladiator.getCurrentHealth() - DRAGON_DAMAGE);
					} while(smallHealth != 0);
					break;
				default:
					System.out.println("Error! Unrecognized monster.");
					break;
				} // end of monster switch statement
// update the treasure carried of the gladiator
				
				myGladiator.setTreasureCarried(myGladiator.getTreasureCarried() + windfall);
// printouts needed
				System.out.printf("%s, the Gladiator, %s the %s!%n", name, boutOutcome, monsterName);
				break;
			case REST:
				hitPoints = 2;
				myGladiator.setCurrentHealth((myGladiator.getCurrentHealth() + hitPoints));
				myGladiator.setTreasureCarried(myGladiator.getTreasureCarried()- REST_COST);
				System.out.println("");
				System.out.printf("%s the Gladiator rests, gaining %d hit points.%n", name, hitPoints);
				System.out.printf("Hit points are now: %d%n", myGladiator.getCurrentHealth());
				break;
			case SHOP:
				weaponChoice = getWeaponChoiceOption(myScanner);
				switch(weaponChoice) {
				case CLUB: 
					Club myClub = new Club();
					myGladiator.setTreasureCarried(myGladiator.getTreasureCarried() - myClub.getCost());
					myGladiator.setWeapon(myClub);
					break;
				case SWORD:
					Sword mySword = new Sword();
					myGladiator.setTreasureCarried(myGladiator.getTreasureCarried() - mySword.getCost());
					//myGladiator.setWeapon(mySword);
					break;
				case ARROW:
					Arrow myArrow = new Arrow();
					myGladiator.setTreasureCarried(myGladiator.getTreasureCarried() - myArrow.getCost());
					//myGladiator.setWeapon(myArrow);
					//break;
				case GUN:
					Gun myGun = new Gun();
					myGladiator.setTreasureCarried(myGladiator.getTreasureCarried() - myGun.getCost());
					//myGladiator.setWeapon(myGun);
					break;
				default:
					System.out.println("Error! Unrecognized weapon.");
					break;
				}
				arenaChoice = getArenaChoiceOption(myScanner);
				switch(arenaChoice) {
				case RAGS:
					Rags myRags = new Rags();
					myGladiator.setTreasureCarried(myGladiator.getTreasureCarried() - myRags.getCost());
					myGladiator.setArmor(myRags);
					break;
				case LEATHER: 
					Leather myLeather = new Leather();
					myGladiator.setTreasureCarried(myGladiator.getTreasureCarried() - myLeather.getCost());
					//myGladiator.setArmor(myLeather);
					break;
				case KEVLAR:
					Kevlar myKevlar = new Kevlar();
					myGladiator.setTreasureCarried(myGladiator.getTreasureCarried() - myKevlar.getCost());
					//myGladiator.setArmor(myKevlar);
					break;
				case IRON: 
				Iron myIron = new Iron();
				myGladiator.setTreasureCarried(myGladiator.getTreasureCarried() - myIron.getCost());
				//myGladiator.setArmor(myIron);
					break; 
				default:
					System.out.println("Error! Unrecognized armor.");
					break;
				}
				System.out.println(myGladiator.toString());
			case STATUS:
				System.out.println("");
				System.out.printf("%s the Gladiator%n", name);
				System.out.printf("Hit points: %d Silver: %.1f%n", myGladiator.getCurrentHealth(), myGladiator.getTreasureCarried());
				System.out.printf("Weapon: %s%n", myGladiator.getWeapon());
				System.out.printf("Armor: %s%n", myGladiator.getArmor());
				break;
			case QUIT:
				System.out.println("");
				System.out.printf("%s The Gladiator has left the building.%n", name);
				System.out.printf("Goodbye, %s. Thank you for playing.", name);
				break;
			default:
				System.out.println("Error! Unrecognized menu choice.");
				break;
			} // end of action switch statement
		} // end of the while loop
		myScanner.close();
	} // end of main method

	/**
	 * purpose - static method returns an integer, called menu_choice. This method
	 * should: - display the menu - prompt the user to enter a menu option -
	 * validate this entry - if it is valid return the integer number of the menu
	 * entry - if it is invalid, display an error, and keep asking for a valid menu
	 * choice.
	 *
	 * @param input - a Scanner object to permit user input
	 * @return
	 * @return menu_choice - an integer representing the user's valid menu choice
	 */
	public static int getValidMenuChoice(Scanner input) {
		int menu_choice;
		boolean isValid = false;
// Declare variables for Object
		int ENTER_ARENA = 1;
		int QUIT = 5;
		int REST = 2;
		int SHOP = 3;
		int STATUS = 4;
		do {
			System.out.println("\nChoose an Action\n");
// display menu list for menu choice
			System.out.printf("%d - Enter the Arena\n", ENTER_ARENA);
			System.out.printf("%d - Rest at the Healer's Tent\n", REST);
			System.out.printf("%d - Buy Equipment at the Bazaar\n", SHOP);
			System.out.printf("%d - Display Status\n", STATUS);
			System.out.printf("%d - Quit the Game\n", QUIT);
			System.out.print("\nWhat would you like to do: ");
			menu_choice = input.nextInt();
			isValid = !(menu_choice < ENTER_ARENA || menu_choice > QUIT);
			System.out.println((isValid ? "" : "Invalid menu choice. Please enter a number from the menu.\n"));
		} while (!isValid);
		return menu_choice;
	} // end of getValidMenuChoice

	/**
	 * 
	 * @param input
	 * @return an integer, called getValidMonsterChoice
	 */
	public static int getValidMonsterChoice(Scanner input) {
		int monster_choice;
		boolean isValid = false;
		int GOBLIN = 1;
		int OGRE = 2;
		int GIANT = 3;
		int DRAGON = 4;
		do {
			System.out.println("\nChoose an Opponent\n");
// display menu list for monster choice
			System.out.printf("%d - Goblin\n", GOBLIN);
			System.out.printf("%d - Ogre\n", OGRE);
			System.out.printf("%d - Giant\n", GIANT);
			System.out.printf("%d - Dragon\n", DRAGON);
			//System.out.printf("%d - Quit the Game\n", QUIT);
			System.out.print("\nWhat will you fight: ");
			monster_choice = input.nextInt();
			isValid = !(monster_choice < GOBLIN || monster_choice > DRAGON);
			System.out.println((isValid ? "" : "Invalid menu choice. Please enter a number from the menu.\n"));
	
		} while (!isValid);
		return monster_choice;
	} // end of getValidMonsterChoice
	public static int getWeaponChoiceOption(Scanner input) {
		int weapon_choice;
		boolean isValid =  false;
		int CLUB = 1;
		int SWORD = 2;
		int ARROW = 3;
		int GUN = 4;
		String WEAPON = "Weapon";
		String DMG = "Dmg";
		String COST = "Cost";
		do {
			System.out.printf("   %5s     %5s   %5s\n", WEAPON, DMG, COST);
			System.out.println("----------------------------------------");
			System.out.printf("1.) %d - Club      2     1.0\n", CLUB);
			System.out.printf("2.) %d - Sword     4     2.5\n", SWORD);
			System.out.printf("3.) %d - Arrow     6     4.5\n", ARROW);
			System.out.printf("4.) %d - Gun       8     7.0\n", GUN);
			
			System.out.print("\nWhat weapon you want: ");
			weapon_choice = input.nextInt();
			isValid = !(weapon_choice < CLUB || weapon_choice >GUN);
			System.out.println((isValid ? "" : "Invalid weapon choice. Please enter a number from the menu.\n"));
		}while(!isValid);
		return weapon_choice;
	}
	public static int getArenaChoiceOption(Scanner input) {
		int arena_choice;
		boolean isValid = false;
		int RAGS = 1;
		int LEATHER = 2;
		int KEVLAR = 3;
		int IRON = 4;
		String ARMOR = "Armor";
		String DMG = "Dmg";
		String COST = "Cost";
		do {
			System.out.printf("    %5s     %5s   %5s\n", ARMOR, DMG, COST);
			System.out.println("----------------------------------------");
			System.out.printf("1.) %d - Rags      1     1.0\n", RAGS);
			System.out.printf("2.) %d - Leather   3     2.5\n", LEATHER);
			System.out.printf("3.) %d - Kevlar    5     4.5\n", KEVLAR);
			System.out.printf("4.) %d - Iron      8     7.0\n", IRON);
			
			System.out.print("\nWhat armor you want: ");
			arena_choice = input.nextInt();
			isValid = !(arena_choice < RAGS || arena_choice >IRON);
			System.out.println((isValid ? "" : "Invalid weapon choice. Please enter a number from the menu.\n"));
		}while(!isValid);
		return arena_choice;
	}
	
} // end of class Arena