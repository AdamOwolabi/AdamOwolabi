/**
 * Object File ClassName - An example class for assignment: CE Composition
 * Copyright 2021 Howard Community College
 *
 * @author Adam Owolabi
 * @version 1.0
 * 
 */
public class Rags extends Armor{
	
	
	private String color;
	
	@Override
	public String toString() {
		return String.format("Armor: Rags [cost:%.1f, damage:%d, color: %s]",  this.getCost(), this.getDamage(), this.color);
	}
	
	public Rags() {
		super();
		this.setCost(1.0);
		this.setDamage(1);
		color = "dull grey";
	}
	public Rags(double cost, int damage, String color) {
		super(cost, damage);
		this.color = color;
	}
	
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	
}
