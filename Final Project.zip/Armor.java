
abstract public class Armor {
	private double cost;
	private int damage;
	
	@Override
	public String toString() {
		return "Armor [cost=" + cost + ", damage=" + damage + "]";
	}
	public Armor(double cost, int damage) {
		super();
		this.cost = cost;
		this.damage = damage;
	}
	public Armor() {
		cost = 0;
		damage = 0;
	}
	
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
	public int getDamage() {
		return damage;
	}
	public void setDamage(int damage) {
		this.damage = damage;
	}
}
