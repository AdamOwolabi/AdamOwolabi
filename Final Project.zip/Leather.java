
public class Leather extends Armor {
	
	private double thickness;

	public Leather() {
		super();
		this.setCost(4.5);
		this.setDamage(3);
		thickness = 2.0;
	}
	
	@Override
	public String toString() {
		return "Leather [Armor [cost=" + this.getCost() + ", damage=" + this.getDamage() + ", thickness=" + thickness + "]]";
	}
	
	public Leather(double cost, int damage, double thickness) {
		super(cost, damage);
		this.thickness = thickness;
	}


	public void setThickness(double thickness) {
		this.thickness = thickness;
	}
	public double getThickness() {
		return thickness;
	}
}
