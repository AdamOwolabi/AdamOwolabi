
public class Iron extends Armor {
	boolean isShiny;
	public Iron() {
		super();
		this.setCost(0);
		this.setDamage(0);
		isShiny = false;
		
	}
	
	@Override
	public String toString() {
		return "Iron [cost=" + this.getCost() + ", damage=" + getDamage() + ", isEngraved=" + isShiny + "]";
	}

	public Iron(double cost, int damage, boolean isShiny) {
		super(cost, damage);
		this.isShiny = isShiny;
	}

	public void setIsShiny(boolean isShiny) {
		this.isShiny = isShiny;
	}

	public boolean getIsShiny() {
		return isShiny;
	}
}

