public class Ogre extends Monster{
private String ogreTribe;

		// zero argument constructor
		public Ogre() {
			super();
			ogreTribe = "my tribe";
			this.setCurrentHealth(2);
			this.setDamage(3);
			this.setTreasureCarried(4.0);
		}
		
		//toString Method
		@Override
		public String toString() {
			return "Ogre [Monster [currentHealth=" + this.getCurrentHealth() + ",damageDealt=" + this.getDamage() + ", treasureCarried="
					+ this.getTreasureCarried() + "],"+ "Ogre [ogreTribe = "+ ogreTribe + "]]";
		} 
		//full argument constructor
		public Ogre(int currentHealth, int damage, double treasureCarried, String ogreTribe) {
			super(currentHealth, damage, treasureCarried);
			this.ogreTribe = ogreTribe;
		}
		//getters and setters
		public void setOgreTribe(String ogreTribe) {
			this.ogreTribe = ogreTribe;
		}
		public String getOgreTribe() {
			return ogreTribe;
		}
}
