
public abstract class Monster implements Combatant{
	//instance variables
		public int currentHealth;
		public int damage;
		private double treasureCarried = 10.0; 
		
		//toString method
		@Override
		public String toString() {
			return "Monster [currentHealth=" + currentHealth + ", damageDealt=" + damage + ", treasureCarried="
					+ treasureCarried + "]";
		} 
		//getter and setters
		public int getCurrentHealth() {
			return currentHealth;
		}
		public int getDamage() {
			return damage;
		}
		public double getTreasureCarried() {
			return treasureCarried;
		}
		public void setCurrentHealth(int currentHealth) {
			this.currentHealth = currentHealth;
		}
		public void setDamage(int damage) {
			this.damage = damage;
		}
		public void setTreasureCarried(double treasureCarried) {
			this.treasureCarried = treasureCarried;
		}
		//zero argument constructor
		public Monster() {
			currentHealth = 0;
			damage = 0;
			treasureCarried = 10.0;
		}
		//full arguement constructor
		public Monster(int currentHealth, int damageDealt, double treasureCarried) {
			this();
			this.currentHealth = currentHealth;
			this.damage = damage;
			this.treasureCarried = treasureCarried;
		}
		
		@Override
		public void attack(Combatant defender, int damageDealt) {
			// TODO Auto-generated method stub
			
		}
		@Override
		public void getAttacked(Combatant attacker, int damageSustained) {
			// TODO Auto-generated method stub
			
		}
}
