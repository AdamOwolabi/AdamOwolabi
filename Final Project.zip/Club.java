
public class Club extends Weapon {
	
		//Instance variables.
		
		private String woodType;

		
		// toString Method
		@Override
		public String toString() {
			return String.format("Club [woodType: "+ this.woodType + " ,Weapon[cost: "+ this.getCost() + ",damage: " + this.getDamage() + "]]");
		}
		// zero-argument Constructor
		public Club() {
			super();
			woodType = "Oak";
			this.setCost(1.0);
			this.setDamage(2);
		}
		// Full argument Constructor
		public Club(double cost, int damage, String woodType) {
			
			super(cost, damage);
			this.woodType = woodType;
		}
		
		//getters and setters
		public String getWoodType() {
			return woodType;
		}

		public void setWoodType(String woodType) {
			this.woodType = woodType;
		}
}
