
public class Giant extends Monster{
	int annoyanceLevel;
	public Giant() {
		super();
		annoyanceLevel = 0;
 }
	
	public Giant(int currentHealth, int damage, double treasureCarried, int annoyanceLevel) {
		
		super(damage, currentHealth, treasureCarried);
		annoyanceLevel = 5;
		this.setCurrentHealth(20); 
		this.setDamage(8);
		this.setTreasureCarried(2.0);
	}
	
@Override
public String toString() {
return "Giant [Monster [currentHealth=" + this.getCurrentHealth() + ", damage=" + this.getDamage() + ", treasureCarried="
		+ this.getTreasureCarried() + "],"+ "annoyanceLevel: "+ annoyanceLevel + "]";
}
}
