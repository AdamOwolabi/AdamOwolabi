
	public class Goblin extends Monster {

		// instance variables
		private int annoyanceLevel;
	
	
		// constructor
				public Goblin() {
				
					
					annoyanceLevel = 5;
					this.setCurrentHealth(3); 
					this.setDamage(3);
					this.setTreasureCarried(10.0);
				}
				
		@Override
		public String toString() {
			return "Goblin [Monster [currentHealth=" + this.getCurrentHealth() + ", damage=" + this.getDamage() + ", treasureCarried="
					+ this.getTreasureCarried() + "],"+ "annoyanceLevel: "+ annoyanceLevel + "]";
		}
		
		

	
		// constructor that receives 3 parameter
		public Goblin(int currentHealth, int damage, double treasureCarried, int annoyanceLevel) {
			this.currentHealth = currentHealth;
			this.damage = damage;
			this.annoyanceLevel = annoyanceLevel;
		}
		
		// methods to set the name in the object
		public void setAnnoyanceLevel(int annoyanceLevel) {
			this.annoyanceLevel = annoyanceLevel;
		}

		// methods to retrieve the name from the object
		public int getAnnoyanceLevel() {
			return annoyanceLevel;
		}
		
		@Override
		public void attack(Combatant defender, int damageDealt) {
			System.out.println("The Goblin is attacking");
			
		}

		@Override
		public void getAttacked(Combatant attacker, int damageSustained) {
			Goblin op = new Goblin();
			System.out.println("The Goblin is being attacked");
			
			op.setCurrentHealth(op.getCurrentHealth() - op.getDamage());
			
			System.out.println(op.getCurrentHealth());
			if (op.getCurrentHealth() >= 1) {
				System.out.println("Goblin is still alive");
			} else {
				System.out.println("Goblin has been killed");
			}
		}
 }
