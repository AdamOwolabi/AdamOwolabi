public class Arrow extends Weapon {
	boolean isEngraved;
	public Arrow() {
		super();
		this.setCost(4.5);
		this.setDamage(6);
		isEngraved = false;
		
	}
	
	@Override
	public String toString() {
		return "Arrow [cost=" + this.getCost() + ", damage=" + getDamage() + ", isEngraved=" + isEngraved + "]";
	}

	public Arrow(double cost, int damage, boolean isEngraved) {
		super(cost, damage);
		this.isEngraved = isEngraved;
	}

	public void setIsEngraved(boolean isEngraved) {
		this.isEngraved = isEngraved;
	}

	public boolean getIsEngraved() {
		return isEngraved;
	}
}

