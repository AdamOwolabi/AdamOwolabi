
public class Sword extends Weapon{
	
	boolean isEngraved;
	public Sword() {
		super();
		this.setCost(0);
		this.setDamage(0);
		isEngraved = false;
		
	}
	
	@Override
	public String toString() {
		return "Weapon: Sword [ cost=" + this.getCost() + ", damage=" + getDamage() + ", isEngraved=" + isEngraved + "]";
	}

	public Sword(double cost, int damage, boolean isEngraved) {
		super(cost, damage);
		this.isEngraved = isEngraved;
	}

	public void setIsEngraved(boolean isEngraved) {
		this.isEngraved = isEngraved;
	}

	public boolean getIsEngraved() {
		return isEngraved;
	}
}
