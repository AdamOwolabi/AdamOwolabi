
public class Dragon extends Monster {
	int annoyanceLevel;
	public Dragon() {
		super();
		annoyanceLevel = 0;
 }
	
	public Dragon(int currentHealth, int damage, double treasureCarried, int annoyanceLevel) {
		
		super(damage, currentHealth, treasureCarried);
		annoyanceLevel = 5;
		this.setCurrentHealth(40); 
		this.setDamage(13);
		this.setTreasureCarried(2.0);
	}
	
@Override
public String toString() {
return "Dragon [Monster [currentHealth=" + this.getCurrentHealth() + ", damage=" + this.getDamage() + ", treasureCarried="
		+ this.getTreasureCarried() + "],"+ "annoyanceLevel: "+ annoyanceLevel + "]";
}
}

