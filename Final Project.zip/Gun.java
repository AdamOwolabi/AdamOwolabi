public class Gun extends Weapon {
	boolean isDead;
	public Gun() {
		super();
		this.setCost(7.0);
		this.setDamage(8);
		isDead = false;
		
	}
	
	@Override
	public String toString() {
		return "Gun[cost=" + this.getCost() + ", damage=" + getDamage() + ", isDead=" + isDead + "]";
	}

	public Gun(double cost, int damage, boolean isDead) {
		super(cost, damage);
		this.isDead = isDead;
	}

	public void setIsEngraved(boolean isDead) {
		this.isDead = isDead;
	}

	public boolean getIsEngraved() {
		return isDead;
	}
}
